# Bundled assets and their licences

Chess Tutor is free software under the GNU General Public License v3.0 (`LICENSE`).
This file records every third-party asset the app ships, so the licence of each one is
known before release (plan.md, section 9). Add a row whenever an asset is added.

| Asset | Where in the repo | Source | Licence |
|---|---|---|---|
| Stockfish 19 chess engine | `app/src/main/jniLibs/*/libstockfish.so` (built by CI, not committed) | Official source, tag `sf_19`, commit `edb0d9db6731067ec50ce619ff372b463bc4dd5d`, built by `tools/build_stockfish_android.sh` | GPL-3.0 |
| Stockfish neural network `nn-1a298aa575a0.nnue` | Embedded inside `libstockfish.so` | Published by the Stockfish project for Stockfish 19; downloaded and SHA-256 checked by Stockfish's own build script | CC0 1.0: "All networks in this repository were uploaded by the authors under the CC0 license" (github.com/official-stockfish/networks, checked 27 Oct 2026). Shipped inside the GPL-3.0 Stockfish binary |
| Schibsted Grotesk (SemiBold) | `app/src/main/res/font/schibsted_grotesk_semibold.ttf` | Google Fonts release, version 1.100 (The Schibsted-Grotesk Project Authors) | SIL Open Font License 1.1 (`licenses/OFL-1.1.txt`) |
| Inter (Regular, Medium, SemiBold) | `app/src/main/res/font/inter_*.ttf` | Google Fonts release, Inter 4.001 (The Inter Project Authors) | SIL Open Font License 1.1 (`licenses/OFL-1.1.txt`) |
| JetBrains Mono | `app/src/main/res/font/jetbrains_mono.ttf` | JetBrains Mono 2.211 | SIL Open Font License 1.1 (`licenses/OFL-1.1.txt`) |
| Puzzle pack v2 (13,485 puzzles, with accepted alternative moves) | `app/src/main/assets/puzzles.tsv.gz` | Lichess open puzzle database (download of 2 Oct 2026), selected and checked by `tools/build_puzzle_pack.py`; the alternatives were found with Stockfish 19 on the developer's PC at build time (the engine is not part of this file) | CC0 1.0 (public domain dedication) |
| Opening database (3,865 named lines with ECO codes) | `app/src/main/assets/openings.tsv.gz` | `lichess-org/chess-openings` (a.tsv to e.tsv, download of 22 Oct 2026), moves converted from SAN to UCI by `tools/build_openings.py` with python-chess (GPL-3.0, used only at build time, not part of this file) | CC0 1.0 (public domain dedication) |
| Maia networks 1100 to 1900 (human-like move prediction, policy part only) | `app/src/main/assets/maia/maia-1100.bin` to `maia-1900.bin` | CSSLab/maia-chess (`maia_weights/maia-XXXX.pb.gz`, download of 23 Oct 2026), converted by `tools/maia_net.py` (batch norm folded in, 16-bit values); checked against lc0 v0.32.1 | GPL-3.0 (maia-chess repository) |
| Maia policy move table | `app/src/main/assets/maia/maia_moves.tsv` | Built by `tools/maia_net.py` from lc0's 1858-move policy list (`lczero-training/tf/policy_index.py`) and convolution policy map (`lc0/src/neural/tables/policy_map.h`) | GPL-3.0 (LeelaChessZero) |
| Lessons (text, positions and exercises) | `app/src/main/assets/lessons/*.json` | Original, written for this project. From Phase 6C, many exercise positions and solutions in the newer courses are puzzles from the Lichess puzzle database (CC0, the same source as the puzzle pack) | GPL-3.0, with the app (the puzzle positions themselves are CC0) |
| Coaches (Pip, Rookie, Sage) in four moods (ready, thinking, kind, proud) | Sources: `design/mascot/<coach>_<mood>.svg` (12 files). In the app: `app/src/main/res/drawable/mascot_<coach>_<mood>.xml`, generated from the SVGs by `tools/mascot_svg_to_vector.py` | Original artwork made for this project (drawn with Claude, Phase 7) | GPL-3.0, with the app |
| Streak flame, lit and off | `app/src/main/res/drawable/ic_flame_lit.xml`, `ic_flame_off.xml` | Original art for Chess Tutor, GPL-3.0 with the app |
| Result icons, crown and toppled king | `app/src/main/res/drawable/ic_result_win.xml`, `ic_result_loss.xml` | Original art for Chess Tutor, GPL-3.0 with the app |
| Metal icons and medals | `app/src/main/res/drawable-nodpi/icon_*.webp`, `medal_*.webp` | Made for Chess Tutor by `tools/art/metal.html` from Material Symbols shapes (Google, Apache-2.0), lit with the HDRI "Brown Photostudio 02" from Poly Haven (CC0) |
| Scene and piece pictures | `app/src/main/res/drawable-nodpi/art_*.webp` | Rendered for Chess Tutor from the Poly Haven model "Chess Set" by Riley Queen (CC0) lit with the HDRI "Studio Small 09" (CC0). The renders are GPL-3.0 with the app; `tools/art` makes them |
| Bot faces (12 animal characters: Pebble, Wayne, Juno, Bramble, Ziggy, Marlo, Tessa, Kofi, Ingrid, Nova, Titan, Bolt) | Sources: `design/bots/*.svg`, drawn by `tools/make_bot_faces.py`. In the app: `app/src/main/res/drawable/bot_*.xml`, converted by `tools/mascot_svg_to_vector.py` | Original artwork made for this project | GPL-3.0, with the app |
| Design system colours and components | `app/src/main/java/com/chesstutor/app/design/` | Original, made for this project | GPL-3.0, with the app |
| Piece set "cburnett" (shown as "Classic") | Sources: `design/pieces/cburnett/*.svg`. In the app: `app/src/main/res/drawable/piece_cburnett_*.xml`, generated by `tools/PieceSvgToVector.java` | Colin M.L. Burnett, via `lichess-org/lila` `public/piece/cburnett` (licence listed in lila's `COPYING.md`) | GPLv2 or later, used here under GPL-3.0 (`LICENSE`) |
| Launcher icon (D46) | `app/src/main/res/drawable/ic_launcher_foreground.xml` and `ic_launcher_monochrome.xml`: the Classic white knight from `piece_cburnett_wn.xml`, scaled onto an ink background | Colin M.L. Burnett (the knight), via `lichess-org/lila` | GPLv2 or later, used here under GPL-3.0 (`LICENSE`) |
| Piece set "merida" | `design/pieces/merida/*.svg`; `piece_merida_*.xml` | Armando Hernandez Marroquin, via `lichess-org/lila` `public/piece/merida` | GPLv2 or later, used here under GPL-3.0 (`LICENSE`) |
| Piece set "chessnut" | `design/pieces/chessnut/*.svg`; `piece_chessnut_*.xml` | Alexis Luengas, `LexLuengas/chessnut-pieces` ("Copyright 2015 Alexis Luengas"), via `lichess-org/lila` | Apache License 2.0 (`licenses/Apache-2.0.txt`). Converted from SVG to VectorDrawable; shapes unchanged |
| Piece set "fantasy" | `design/pieces/fantasy/*.svg`; `piece_fantasy_*.xml` | Maurizio Monge, `maurimo/chess-art`, via `lichess-org/lila` | MIT (`licenses/MIT-fantasy-pieces.txt`) |
| Board colour themes | `app/src/main/java/com/chesstutor/app/board/BoardTheme.kt` | Original, made for this project | GPL-3.0, with the app |
| Launcher icon for Android 7 | `app/src/main/res/mipmap-*/ic_launcher*.webp` | Rendered from the vector launcher icon above (the Classic knight) by `tools/render_launcher_icons.py` | GPLv2 or later, used here under GPL-3.0 (`LICENSE`) |

Sound effects (`app/src/main/res/raw/sfx_*.ogg`), played by `audio/ChessSoundManager.kt`:

| File | Original file | Pack | Licence |
|---|---|---|---|
| `sfx_move.ogg` | `impactWood_light_002.ogg` | Kenney "Impact Sounds" 1.0 (kenney.nl) | CC0 1.0 |
| `sfx_capture.ogg` | `impactWood_heavy_001.ogg` | Kenney "Impact Sounds" 1.0 | CC0 1.0 |
| `sfx_castle.ogg` | `impactPlank_medium_000.ogg` | Kenney "Impact Sounds" 1.0 | CC0 1.0 |
| `sfx_check.ogg` | `glass_002.ogg` | Kenney "Interface Sounds" 1.0 | CC0 1.0 |
| `sfx_promote.ogg` | `maximize_006.ogg` | Kenney "Interface Sounds" 1.0 | CC0 1.0 |
| `sfx_win.ogg` | `confirmation_004.ogg` | Kenney "Interface Sounds" 1.0 | CC0 1.0 |
| `sfx_lose.ogg` | `minimize_008.ogg` | Kenney "Interface Sounds" 1.0 | CC0 1.0 |
| `sfx_correct.ogg` | `confirmation_001.ogg` | Kenney "Interface Sounds" 1.0 | CC0 1.0 |
| `sfx_wrong.ogg` | `error_008.ogg` | Kenney "Interface Sounds" 1.0 | CC0 1.0 |
| `sfx_tap.ogg` | `click_002.ogg` | Kenney "Interface Sounds" 1.0 | CC0 1.0 |

The files are unchanged copies. CC0 needs no credit; Kenney asks for an optional one, which the
in-app licences page gives (kenney.nl).

**In the app:** Settings > About > Open-source licences lists every part above with its author
and licence (`feature/account/LicencesScreen.kt`, `CREDITS`), and shows the full licence texts
bundled in `app/src/main/assets/licenses/`: `GPL-3.0.txt` (the official text from gnu.org, also
the repository's `LICENSE`), `Apache-2.0.txt`, `MIT-fantasy-pieces.txt` and `OFL-1.1.txt`
(copies of `licenses/`). Libraries compiled into the app: AndroidX and Jetpack Compose (Apache
2.0), Kotlin and kotlinx.coroutines (Apache 2.0), OkHttp and Moshi (Apache 2.0),
desugar_jdk_libs (GPL v2 with the Classpath Exception).

This is a record, not legal advice.
