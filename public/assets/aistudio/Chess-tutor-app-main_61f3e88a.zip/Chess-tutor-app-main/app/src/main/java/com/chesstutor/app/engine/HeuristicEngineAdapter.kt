package com.chesstutor.app.engine

import com.chesstutor.app.core.Move
import com.chesstutor.app.core.Position
import com.chesstutor.app.core.engine.LocalChessEngine

/**
 * Application boundary for the legacy pure-Kotlin heuristic engine.
 *
 * The chess core remains the source of truth for rules. This adapter keeps
 * engine implementation details out of application-facing engine clients.
 */
class HeuristicEngineAdapter(
    private val engine: LocalChessEngine = LocalChessEngine()
) {
    suspend fun selectMove(position: Position, rating: Int): Move =
        engine.selectMoveForElo(position, rating)

    suspend fun findBestMove(position: Position, depth: Int = 3): Pair<Move, com.chesstutor.app.core.engine.Evaluation> =
        engine.findBestMove(position, depth)

    suspend fun evaluatePosition(position: Position, depth: Int = 3): com.chesstutor.app.core.engine.Evaluation =
        engine.evaluatePosition(position, depth)
}
