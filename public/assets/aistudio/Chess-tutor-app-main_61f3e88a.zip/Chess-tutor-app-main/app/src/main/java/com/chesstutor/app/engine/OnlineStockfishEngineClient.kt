package com.chesstutor.app.engine

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.Call
import okhttp3.Callback
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class OnlineStockfishEngineClient(
    private val fallback: EngineClient = LocalFallbackEngineClient()
) : EngineClient {

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(4, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .writeTimeout(4, TimeUnit.SECONDS)
        .build()

    private val evaluationCache = androidx.collection.LruCache<String, PositionAnalysis>(256)

    @Volatile
    private var rateLimitCooldownUntil: Long = 0L

    @Volatile
    private var circuitOpenUntil: Long = 0L

    private val consecutiveFailures = AtomicInteger(0)

    /** Off when the player turned the online engine off (Settings > Engine): the Lite engine answers instead. */
    @Volatile
    var enabled: Boolean = true

    override suspend fun initialize() {
        fallback.initialize()
    }

    private suspend fun Call.awaitCancellable(): Response = suspendCancellableCoroutine { cont ->
        cont.invokeOnCancellation {
            runCatching { cancel() }
        }
        enqueue(object : Callback {
            override fun onFailure(call: Call, e: IOException) {
                if (cont.isActive) cont.resumeWithException(e)
            }

            override fun onResponse(call: Call, response: Response) {
                if (cont.isActive) {
                    cont.resume(response)
                } else {
                    response.close()
                }
            }
        })
    }

    override suspend fun analyze(request: AnalysisRequest): PositionAnalysis = withContext(Dispatchers.IO) {
        val targetDepth = (request.depth ?: 10).coerceIn(6, 15)
        val cacheKey = "${request.fen}|$targetDepth"

        evaluationCache.get(cacheKey)?.let { cached ->
            logD("OnlineStockfish cache hit for position: ${request.fen.take(20)}...")
            return@withContext cached.copy(requestId = request.requestId)
        }

        if (!enabled) return@withContext fallback.analyze(request)

        val now = System.currentTimeMillis()
        // If recently rate-limited or circuit breaker is open, skip external calls and use fast deterministic fallback
        if (now < rateLimitCooldownUntil || now < circuitOpenUntil) {
            logD("OnlineStockfish in cooldown/circuit-open; using local fallback")
            return@withContext fallback.analyze(request)
        }

        // Strategy 1: stockfish.online (fast GET API)
        try {
            val encodedFen = URLEncoder.encode(request.fen, "UTF-8")
            val url = "https://stockfish.online/api/s/v2.php?fen=$encodedFen&depth=$targetDepth"
            val httpRequest = Request.Builder()
                .url(url)
                .header("User-Agent", "ChessTutorAndroid/2.0")
                .get()
                .build()

            val call = httpClient.newCall(httpRequest)
            call.awaitCancellable().use { response ->
                val body = runCatching { response.body?.string() }.getOrNull()
                val isRateLimited = response.code == 429 ||
                    body?.contains("rate limit", ignoreCase = true) == true

                if (isRateLimited) {
                    logW("stockfish.online rate limit encountered; activating 2-minute cooldown")
                    rateLimitCooldownUntil = System.currentTimeMillis() + 120_000L
                    return@withContext fallback.analyze(request)
                }

                if (response.isSuccessful && !body.isNullOrBlank()) {
                    val json = JSONObject(body)
                    if (json.optBoolean("success", false)) {
                        val evalDouble = if (json.isNull("evaluation")) null else json.optDouble("evaluation")
                        val mateVal = if (json.isNull("mate")) null else json.optInt("mate")
                        val rawBestMove = json.optString("bestmove", "")
                        val bestMoveUci = parseBestMoveUci(rawBestMove)
                        val continuationStr = json.optString("continuation", "")
                        val pvList = if (continuationStr.isNotBlank()) {
                            continuationStr.trim().split(Regex("\\s+"))
                        } else emptyList()

                        if (bestMoveUci.isNotBlank() && bestMoveUci != "0000") {
                            val cp = evalDouble?.let { (it * 100).toInt() }
                            logD("stockfish.online success: bestMove=$bestMoveUci, cp=$cp, mate=$mateVal")
                            val validated = EngineResultValidator.validate(
                                request = request,
                                analysis = PositionAnalysis(
                                    requestId = request.requestId,
                                    bestMoveUci = bestMoveUci,
                                    centipawns = cp,
                                    mateInMoves = mateVal,
                                    principalVariation = if (pvList.isNotEmpty()) pvList else listOf(bestMoveUci),
                                    depth = targetDepth,
                                    source = EngineSource.CLOUD
                                ),
                                scorePerspective = EngineResultValidator.ScorePerspective.WHITE
                            )
                            consecutiveFailures.set(0)
                            evaluationCache.put(cacheKey, validated)
                            return@withContext validated
                        }
                    }
                }
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            logW("stockfish.online failed: ${e.message}, attempting secondary API...")
        }

        // If cooldown was triggered by Strategy 1, don't spam Strategy 2
        if (System.currentTimeMillis() < rateLimitCooldownUntil) {
            return@withContext fallback.analyze(request)
        }

        // Strategy 2: chess-api.com (POST API)
        try {
            val jsonBody = JSONObject().apply {
                put("fen", request.fen)
                put("depth", targetDepth)
            }
            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = jsonBody.toString().toRequestBody(mediaType)
            val httpRequest = Request.Builder()
                .url("https://chess-api.com/v1")
                .header("User-Agent", "ChessTutorAndroid/2.0")
                .post(requestBody)
                .build()

            val call = httpClient.newCall(httpRequest)
            call.awaitCancellable().use { response ->
                val body = runCatching { response.body?.string() }.getOrNull()
                val isRateLimited = response.code == 429 ||
                    body?.contains("rate limit", ignoreCase = true) == true

                if (isRateLimited) {
                    logW("chess-api.com rate limit encountered; activating 2-minute cooldown")
                    rateLimitCooldownUntil = System.currentTimeMillis() + 120_000L
                    return@withContext fallback.analyze(request)
                }

                if (response.isSuccessful && !body.isNullOrBlank()) {
                    val json = JSONObject(body)
                    val move = json.optString("move", "")
                    val cp = if (json.isNull("centipawns")) {
                        if (json.isNull("eval")) null else (json.optDouble("eval") * 100).toInt()
                    } else json.optInt("centipawns")
                    val mate = if (json.isNull("mate")) null else json.optInt("mate")

                    val pv = mutableListOf<String>()
                    if (move.isNotBlank()) pv.add(move)
                    val contArr = json.optJSONArray("continuationArr")
                    if (contArr != null) {
                        for (i in 0 until contArr.length()) {
                            pv.add(contArr.optString(i))
                        }
                    }

                    if (move.isNotBlank()) {
                        logD("chess-api.com success: bestMove=$move, cp=$cp, mate=$mate")
                        val validated = EngineResultValidator.validate(
                            request = request,
                            analysis = PositionAnalysis(
                                requestId = request.requestId,
                                bestMoveUci = move,
                                centipawns = cp,
                                mateInMoves = mate,
                                principalVariation = pv,
                                depth = targetDepth,
                                source = EngineSource.CLOUD
                            ),
                            scorePerspective = EngineResultValidator.ScorePerspective.WHITE
                        )
                        consecutiveFailures.set(0)
                        evaluationCache.put(cacheKey, validated)
                        return@withContext validated
                    }
                }
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            logW("chess-api.com failed: ${e.message}, falling back to local engine...")
        }

        if (consecutiveFailures.incrementAndGet() >= 2) {
            circuitOpenUntil = System.currentTimeMillis() + 60_000L
        }

        // Strategy 3: Reliable Local Engine Fallback (Offline safe)
        logI("Using offline local chess engine fallback for analysis")
        val fallbackAnalysis = fallback.analyze(request)
        evaluationCache.put(cacheKey, fallbackAnalysis)
        fallbackAnalysis.copy(requestId = request.requestId)
    }

    override suspend fun setStrengthRating(rating: Int) {
        // The public cloud APIs used here do not expose a stable UCI_Elo control.
        // Keep the capability explicit and forward it to the offline fallback.
        fallback.setStrengthRating(rating)
    }

    override suspend fun stop() {
        fallback.stop()
    }

    override suspend fun dispose() {
        fallback.dispose()
    }

    private fun parseBestMoveUci(raw: String): String {
        val trimmed = raw.trim()
        val parts = trimmed.split(Regex("\\s+"))
        return if (parts.size >= 2 && parts[0] == "bestmove") {
            parts[1]
        } else if (parts.isNotEmpty()) {
            parts[0]
        } else ""
    }

    companion object {
        private const val TAG = "OnlineStockfish"

        private fun logD(msg: String) {
            try { Log.d(TAG, msg) } catch (_: Throwable) { println("[$TAG] $msg") }
        }

        private fun logW(msg: String) {
            try { Log.w(TAG, msg) } catch (_: Throwable) { System.err.println("[$TAG] $msg") }
        }

        private fun logI(msg: String) {
            try { Log.i(TAG, msg) } catch (_: Throwable) { println("[$TAG] $msg") }
        }
    }
}
