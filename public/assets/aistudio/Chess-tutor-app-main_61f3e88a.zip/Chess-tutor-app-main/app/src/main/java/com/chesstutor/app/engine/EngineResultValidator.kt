package com.chesstutor.app.engine

import com.chesstutor.app.core.LegalMoveGenerator
import com.chesstutor.app.core.Move
import com.chesstutor.app.core.Position
import com.chesstutor.app.core.PieceColor

/**
 * Validates engine output against the exact position that was analyzed.
 *
 * Engine output is untrusted at the application boundary: a malformed UCI
 * move must never reach the UI or mutate a game.
 */
object EngineResultValidator {

    enum class ScorePerspective {
        /** UCI Stockfish scores are relative to the side to move. */
        SIDE_TO_MOVE,

        /** AnalysisService and cloud clients use a normalized White perspective. */
        WHITE
    }

    fun validate(
        request: AnalysisRequest,
        analysis: PositionAnalysis,
        scorePerspective: ScorePerspective = ScorePerspective.WHITE,
    ): PositionAnalysis {
        require(analysis.requestId == request.requestId) {
            "Engine request id mismatch: expected ${request.requestId}, got ${analysis.requestId}"
        }

        val position = Position.tryFromFen(request.fen).getOrElse {
            throw IllegalArgumentException("Engine request contains invalid FEN")
        }

        val legalMoves = LegalMoveGenerator.generateLegalMoves(position)
        // Compare by UCI text: a move parsed from UCI has no castling or en passant flag, so
        // comparing whole Move objects would reject every castling and en passant answer.
        val legalUci = legalMoves.mapTo(HashSet()) { it.uci }
        val bestMove = analysis.bestMoveUci.trim()

        if (bestMove == "0000") {
            require(legalMoves.isEmpty()) {
                "Engine returned 0000 for a position with ${legalMoves.size} legal moves"
            }
        } else {
            val parsed = try {
                Move.fromUci(bestMove)
            } catch (e: Exception) {
                throw IllegalArgumentException("Engine returned malformed UCI move: $bestMove", e)
            }

            require(parsed.uci in legalUci) {
                "Engine returned illegal move $bestMove for FEN ${request.fen}"
            }
        }

        // Candidate lines are untrusted too: keep only lines that start with a legal move.
        val checkedLines = analysis.lines.filter { line ->
            val first = line.firstMove ?: return@filter false
            val move = runCatching { Move.fromUci(first) }.getOrNull()
            move != null && move.uci in legalUci
        }

        return analysis.copy(lines = checkedLines).normalizedScore(position.sideToMove, scorePerspective)
    }

    private fun PositionAnalysis.normalizedScore(
        sideToMove: PieceColor,
        perspective: ScorePerspective,
    ): PositionAnalysis {
        if (perspective == ScorePerspective.WHITE || sideToMove == PieceColor.WHITE) {
            return this
        }

        return copy(
            centipawns = centipawns?.let { -it },
            mateInMoves = mateInMoves?.let { -it },
            lines = lines.map { line ->
                line.copy(
                    centipawns = line.centipawns?.let { -it },
                    mateInMoves = line.mateInMoves?.let { -it },
                )
            },
        )
    }
}
