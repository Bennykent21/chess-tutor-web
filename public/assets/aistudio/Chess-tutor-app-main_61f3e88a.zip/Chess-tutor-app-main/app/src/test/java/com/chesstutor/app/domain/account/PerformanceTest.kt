package com.chesstutor.app.domain.account

import com.chesstutor.app.core.PieceColor
import com.chesstutor.app.core.Position
import com.chesstutor.app.data.model.GameRecord
import com.chesstutor.app.data.model.GameSource
import com.chesstutor.app.domain.opening.OpeningTree
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class PerformanceTest {

    private val tree by lazy { File("src/main/assets/openings.tsv.gz").inputStream().use(OpeningTree::fromStream) }

    private fun game(
        id: String,
        result: String,
        color: String = "white",
        moves: String = "e2e4 e7e5 g1f3 b8c6 f1c4",
        timeClass: String = "rapid",
        date: Long = 1,
        rating: Int? = null,
        source: GameSource = GameSource.CHESS_COM,
    ) = GameLibrary.summarise(
        GameRecord(
            id = id, dateMillis = date, botName = "Opp", botRating = 1500, result = result,
            pgn = rating?.let { "[${if (color == "white") "WhiteElo" else "BlackElo"} \"$it\"]" }.orEmpty(),
            moveCount = 5, userColor = color, finalFen = "", uciMoves = moves, source = source, timeClass = timeClass,
        ),
        tree,
    )

    @Test
    fun resultsAreSplitByColourTimeAndOpening() {
        val games = listOf(
            game("a", "1-0"),
            game("b", "0-1"),
            game("c", "0-1", color = "black", moves = "d2d4 d7d5 c2c4", timeClass = "blitz"),
            game("d", "1/2-1/2", color = "black", moves = "d2d4 d7d5 c2c4", timeClass = "blitz"),
            game("e", "*"),
        )
        val report = PerformanceCalculator.report(games, emptyMap())
        assertEquals(Wdl(wins = 2, draws = 1, losses = 1), report.overall)
        assertEquals(2.5f / 4, report.overall.score, 0.0001f)

        assertEquals(listOf("As White", "As Black"), report.byColor.map { it.label })
        assertEquals(Wdl(wins = 1, losses = 1), report.byColor[0].wdl)
        assertEquals(PieceColor.BLACK, report.byColor[1].filter.color)

        assertEquals(listOf("Rapid", "Blitz"), report.byTimeClass.map { it.label })
        assertEquals(TimeClass.RAPID, report.byTimeClass[0].filter.timeClass)

        assertEquals(listOf("Italian Game", "Queen's Gambit"), report.byOpening.map { it.label }.sorted())
        assertEquals("Italian Game", report.byOpening.first { it.wdl.games == 2 }.filter.openingFamily)
        assertEquals(0, report.analysedGames)
        assertTrue(report.mistakes.isEmpty())
    }

    @Test
    fun rowsKeepThePagesSourceFilter() {
        val base = GameFilter(source = GameSource.LICHESS)
        val report = PerformanceCalculator.report(listOf(game("a", "1-0", source = GameSource.LICHESS)), emptyMap(), base)
        assertEquals(GameSource.LICHESS, report.byColor.single().filter.source)
        assertEquals(PieceColor.WHITE, report.byColor.single().filter.color)
    }

    @Test
    fun eachMainClockHasItsOwnRatingTrend() {
        val games = listOf(
            game("a", "1-0", rating = 1500, date = 3, timeClass = "blitz"),
            game("b", "1-0", rating = 1480, date = 1, timeClass = "blitz"),
            game("c", "1-0", rating = 1700, date = 2, timeClass = "rapid"),
            game("d", "1-0", rating = 1720, date = 5, timeClass = "rapid"),
            game("e", "1-0", rating = 1999, date = 4, timeClass = "bullet"),
            game("f", "1-0", date = 6, timeClass = "blitz"),
        )
        assertEquals(1500, games[0].playerRating)
        assertNull(games[5].playerRating)
        val trends = PerformanceCalculator.ratingTrends(games)
        assertEquals("rapid first, and bullet has too few games to draw", listOf(TimeClass.RAPID, TimeClass.BLITZ), trends.map { it.timeClass })
        assertEquals(listOf(1480, 1500), trends[1].points.map { it.rating })
    }

    @Test
    fun aPlayerOfNoMainClockStillGetsAGraph() {
        val games = listOf(game("a", "1-0", rating = 1500, date = 1, timeClass = "classical"), game("b", "1-0", rating = 1510, date = 2, timeClass = "classical"))
        assertEquals(listOf(TimeClass.CLASSICAL), PerformanceCalculator.ratingTrends(games).map { it.timeClass })
    }

    @Test
    fun ratingChangeComparesWithThirtyDaysAgo() {
        val day = 86_400_000L
        fun trend(vararg points: Pair<Long, Int>) = RatingTrend(null, points.map { (d, r) -> RatingPoint(d * day, r) })
        assertEquals("the last point at or before the window", 30, trend(10L to 1400, 20L to 1450, 40L to 1470, 60L to 1480).changeSince(60 * day))
        assertEquals("younger than the window: since the first point", -20, trend(50L to 1500, 60L to 1480).changeSince(60 * day))
        assertNull("one point has nothing to compare with", trend(60L to 1480).changeSince(60 * day))
    }

    @Test
    fun aPeriodRunsFromTheRatingHeldThenToToday() {
        val day = 86_400_000L
        val trend = RatingTrend(null, listOf(RatingPoint(10 * day, 1400), RatingPoint(60 * day, 1450), RatingPoint(70 * day, 1480)))
        assertEquals(
            "the line begins at the period's start, at the rating held then, and carries on to today",
            listOf(RatingPoint(50 * day, 1400), RatingPoint(60 * day, 1450), RatingPoint(70 * day, 1480), RatingPoint(80 * day, 1480)),
            trend.within(80 * day, GraphPeriod.MONTH.days).points,
        )
        assertEquals(
            "phone test 3 Nov: a quiet month is a flat line, not the whole history",
            listOf(RatingPoint(75 * day, 1480), RatingPoint(80 * day, 1480)),
            trend.within(80 * day, 5).points,
        )
        assertEquals("all of it, up to today", trend.points + RatingPoint(80 * day, 1480), trend.within(80 * day, GraphPeriod.ALL.days).points)
    }

    /** Phone test 3 Nov: many games a day made the line spike up and down on one spot. */
    @Test
    fun theGraphTakesEachDaysClosingRating() {
        val hour = 3_600_000L
        val day = 24 * hour
        val zone = java.time.ZoneOffset.UTC
        val points = listOf(
            RatingPoint(0, 1500), RatingPoint(2 * hour, 1520), RatingPoint(3 * hour, 1490),
            RatingPoint(day + hour, 1510), RatingPoint(day + 5 * hour, 1530),
        )
        assertEquals(
            "the period's first point, then each day's last game",
            listOf(RatingPoint(0, 1500), RatingPoint(3 * hour, 1490), RatingPoint(day + 5 * hour, 1530)),
            RatingTrend(null, points).forGraph(90, zone),
        )
        val long = List(1000) { RatingPoint(it * day, 1000 + it) }
        val graph = RatingTrend(null, long).forGraph(90, zone)
        assertTrue("at most about the limit: ${graph.size}", graph.size in 85..91)
        assertEquals(long.first(), graph.first())
        assertEquals(long.last(), graph.last())
        assertEquals("oldest first", graph.sortedBy { it.dateMillis }, graph)
    }

    @Test
    fun anOpeningsPictureIsItsShortestNamedLine() {
        val ruy = game("a", "1-0", moves = "e2e4 e7e5 g1f3 b8c6 f1b5 a7a6")
        val family = ruy.openingFamily!!
        val fen = PerformanceCalculator.openingFen(listOf(ruy), family)!!
        assertEquals("the line's own last move was played", Position.tryFromFen(fen).isSuccess, true)
        assertTrue(fen.startsWith("r"))
        assertNull(PerformanceCalculator.openingFen(listOf(ruy), "No such opening"))
    }

    @Test
    fun analysedGamesGiveAccuracyByPhaseAndMistakeKinds() {
        // Scholar's mate with the player as Black: 3...Nf6 walks into mate.
        val moves = listOf("e2e4", "e7e5", "f1c4", "b8c6", "d1h5", "g8f6", "h5f7")
        val evals = listOf(
            PlyEval(0, 20, null, "e2e4"), PlyEval(1, 20, null, "e7e5"), PlyEval(2, 20, null, "g1f3"),
            PlyEval(3, 20, null, "g8f6"), PlyEval(4, 30, null, "d1h5"), PlyEval(5, 50, null, "g7g6"),
            PlyEval(6, null, 1, "h5f7"), GameReviewer.terminalEval(7, GameReviewer.positions(Position.STARTING_FEN, moves).last())!!,
        )
        val g = game("s", "1-0", color = "black", moves = moves.joinToString(" "))
        val review = GameReviewer.review(Position.STARTING_FEN, moves, evals)
        assertTrue(review.moves.all { it.phase == GamePhase.OPENING })

        val report = PerformanceCalculator.report(listOf(g), mapOf("s" to review))
        assertEquals(1, report.analysedGames)
        val opening = report.phases.first { it.phase == GamePhase.OPENING }
        assertEquals(3, opening.moves)
        assertEquals(1, opening.errors)
        assertEquals(0, report.phases.first { it.phase == GamePhase.ENDGAME }.moves)
        assertEquals(mapOf(MistakeKind.ALLOWED_MATE to 1), report.mistakes)
    }

    @Test
    fun mistakeKindsAndPhases() {
        fun move(before: Double, after: Double, quality: MoveQuality) = ReviewedMove(
            ply = 30, uci = "a2a3", san = "a3", mover = PieceColor.WHITE, quality = quality, winBefore = before, winAfter = after,
            bestMove = "h2h3", bestSan = "h3", accuracy = 0.0, fenBefore = Position.STARTING_FEN,
        )
        assertEquals(MistakeKind.MISSED_MATE, PerformanceCalculator.kindOf(move(100.0, 70.0, MoveQuality.BLUNDER)))
        assertEquals(MistakeKind.THREW_WIN, PerformanceCalculator.kindOf(move(85.0, 50.0, MoveQuality.BLUNDER)))
        assertEquals(MistakeKind.OTHER_BLUNDER, PerformanceCalculator.kindOf(move(50.0, 20.0, MoveQuality.BLUNDER)))
        assertEquals(MistakeKind.MISTAKE, PerformanceCalculator.kindOf(move(50.0, 35.0, MoveQuality.MISTAKE)))
        assertNull(PerformanceCalculator.kindOf(move(50.0, 42.0, MoveQuality.INACCURACY)))

        assertEquals(62, GamePhase.materialOf(Position.initial()))
        assertEquals(GamePhase.OPENING, GamePhase.of(10, Position.initial()))
        assertEquals(GamePhase.MIDDLEGAME, GamePhase.of(30, Position.initial()))
        assertEquals(GamePhase.ENDGAME, GamePhase.of(5, Position.fromFen("4k3/8/8/8/8/8/4P3/R3K3 w - - 0 1")))
    }

    @Test
    fun theWeakestOpeningsScoreUnderHalfFromEnoughGames() {
        fun row(label: String, w: Int, d: Int, l: Int) = WdlRow(label, Wdl(w, d, l), GameFilter(openingFamily = label))
        val rows = listOf(
            row("Italian Game", 6, 1, 2),
            row("Sicilian Defense", 1, 1, 4),
            row("French Defense", 0, 0, 2),
            row("Caro-Kann Defense", 2, 0, 3),
            row("Queen's Gambit Declined", 1, 0, 3),
        )
        assertEquals(setOf("Sicilian Defense", "Queen's Gambit Declined"), PerformanceCalculator.weakest(rows))
        assertEquals("nobody is weak while winning", emptySet<String>(), PerformanceCalculator.weakest(listOf(row("Italian Game", 3, 0, 0))))
    }
}
