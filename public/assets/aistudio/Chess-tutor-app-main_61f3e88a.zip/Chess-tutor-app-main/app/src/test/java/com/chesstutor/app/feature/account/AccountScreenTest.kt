package com.chesstutor.app.feature.account

import androidx.compose.ui.test.assertIsEnabled
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.hasClickAction
import androidx.compose.ui.test.hasSetTextAction
import androidx.compose.ui.test.hasText
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onFirst
import androidx.compose.ui.test.onLast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.test.junit4.v2.createComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.onRoot
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.chesstutor.app.data.model.GameRecord
import com.chesstutor.app.data.model.GameSource
import com.chesstutor.app.data.model.LinkedChessProfile
import com.chesstutor.app.data.model.RatingPlatform
import com.chesstutor.app.data.model.RatingTimeControl
import com.chesstutor.app.data.settings.AppSettings
import com.chesstutor.app.design.CtTheme
import com.chesstutor.app.domain.account.AnalysisSummary
import com.chesstutor.app.domain.account.GameFilter
import com.chesstutor.app.domain.account.GameLibrary
import com.chesstutor.app.domain.opening.OpeningTree
import com.chesstutor.app.domain.puzzle.PlayerLevel
import com.chesstutor.app.domain.puzzle.PuzzleStats
import com.chesstutor.app.viewmodel.AppUiState
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode
import java.io.File

/** The Account tab's Overview and Games pages and the game page (step 5A). */
@RunWith(AndroidJUnit4::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = "w400dp-h1600dp-xxhdpi")
class AccountScreenTest {

    @get:Rule
    val compose = createComposeRule()

    private val tree by lazy { File("src/main/assets/openings.tsv.gz").inputStream().use(OpeningTree::fromStream) }

    private val italianFinal = "r1bqk1nr/pppp1ppp/2n5/2b1p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 4 4"

    private fun record(id: String, opponent: String, result: String, color: String, source: GameSource, moves: String, date: Long, timeClass: String = "rapid") =
        GameRecord(
            id = id, dateMillis = date, botName = opponent, botRating = 1450, result = result, pgn = "",
            moveCount = moves.split(' ').size, userColor = color, finalFen = italianFinal, uciMoves = moves,
            source = source, termination = "checkmate", timeClass = timeClass,
        )

    private val games by lazy {
        GamesState(
            loading = false,
            games = GameLibrary.summarise(
                listOf(
                    record("bot_1", "Pip", "1-0", "white", GameSource.ARENA, "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5", date = 1_760_000_000_000),
                    record("chesscom_2", "rookie99", "1-0", "black", GameSource.CHESS_COM, "d2d4 d7d5 c2c4 e7e6", date = 1_759_000_000_000, timeClass = "blitz"),
                    record("lichess_3", "sagefan", "1/2-1/2", "white", GameSource.LICHESS, "e2e4 c7c5 g1f3 d7d6", date = 1_758_000_000_000, timeClass = "bullet"),
                ),
                tree,
            ),
        )
    }

    private val stats = PuzzleStats(rating = 1310, totalXp = 640, playerLevel = PlayerLevel.fromXp(640), dayStreak = 5)

    @Test
    fun overviewShowsTheHeaderLinkFormAndRecentGames() {
        var opened: String? = null
        compose.setContent {
            CtTheme(reduceMotion = true) {
                AccountScreen(state = AppUiState(), games = games, stats = stats, actions = AccountActions(onOpenGame = { opened = it }))
            }
        }
        compose.onNodeWithText("Puzzles").assertExists()
        compose.onNodeWithText("Level ${stats.playerLevel.level}").assertExists()
        compose.onNodeWithContentDescription("5-day streak").assertExists()
        compose.onNodeWithText("Link your account").assertExists()
        compose.onNodeWithText("Recent games").performScrollTo()
        compose.onNodeWithText("@rookie99").assertExists()
        compose.onNodeWithText("Recent activity").assertDoesNotExist()
        compose.onRoot().captureRoboImage("build/outputs/roborazzi/account_overview.png")

        compose.onNodeWithText("Pip").performClick()
        assertEquals("bot_1", opened)
    }

    @Test
    fun overviewShowsBadgesAndOpensOne() {
        val overview = OverviewState(
            badges = listOf(
                com.chesstutor.app.domain.account.Badge("first-win", "First win", "Beat a bot", com.chesstutor.app.domain.account.BadgeKind.GAMES, 1, 1),
                com.chesstutor.app.domain.account.Badge("puzzles-10", "Puzzle starter", "Solve 10 puzzles", com.chesstutor.app.domain.account.BadgeKind.PUZZLES, 4, 10),
            ),
        )
        compose.setContent {
            CtTheme(reduceMotion = true) {
                AccountScreen(state = AppUiState(), games = games, stats = stats, actions = AccountActions(), overview = overview)
            }
        }
        val list = compose.onNode(androidx.compose.ui.test.hasScrollToNodeAction())
        list.performScrollToNode(hasText("Badges"))
        compose.onRoot().captureRoboImage("build/outputs/roborazzi/account_badges.png")
        compose.onNode(androidx.compose.ui.test.hasContentDescription("Puzzle starter: Solve 10 puzzles. 4 of 10.")).performClick()
        compose.onNodeWithText("4 / 10").assertExists()
        compose.onNodeWithText("Solve 10 puzzles").assertExists()
    }

    @Test
    fun gamesPageFiltersInOneSheet() {
        compose.setContent {
            CtTheme(reduceMotion = true) {
                GamesScreen(games = games, initialFilter = GameFilter(), onOpenGame = {}, onBack = {})
            }
        }
        compose.onNodeWithText("3 games").assertExists()
        // The clocks have their own row of chips above the list.
        compose.onAllNodes(androidx.compose.ui.test.hasContentDescription("Blitz") and hasClickAction()).onFirst().performClick()
        compose.onNodeWithText("1 of 3 games").assertExists()
        compose.onNodeWithText("@rookie99").assertExists()
        compose.onAllNodes(androidx.compose.ui.test.hasContentDescription("All") and hasClickAction()).onFirst().performClick()
        compose.onRoot().captureRoboImage("build/outputs/roborazzi/account_games.png")

        compose.onNodeWithText("Filter").performClick()
        // The link card above the list has a "Chess.com" chip too; the sheet's comes last.
        compose.onAllNodesWithText("Chess.com").onLast().performClick()
        compose.onRoot().captureRoboImage("build/outputs/roborazzi/account_games_filter.png")
        compose.onNodeWithText("Show 1 game").performClick()
        compose.onNodeWithText("1 of 3 games").assertExists()
        compose.onNodeWithText("@rookie99").assertExists()
        compose.onNodeWithText("Pip").assertDoesNotExist()

        compose.onNodeWithText("Filters (1)").performClick()
        compose.onNodeWithText("Clear").performClick()
        compose.onNodeWithText("Losses").performClick()
        compose.onNodeWithText("Show 1 game").assertExists()
        compose.onNodeWithText("Draws").performClick()
        compose.onNodeWithText("Show 1 game").performClick()
        compose.onNodeWithText("@sagefan").assertExists()
        compose.onNodeWithText("@rookie99").assertDoesNotExist()

        compose.onNodeWithText("Filters (1)").performClick()
        compose.onNodeWithText("Clear").performClick()
        compose.onNodeWithContentDescription("Search games").performTextInput("nobody")
        compose.onNodeWithText("Show 0 games").performClick()
        compose.onNodeWithText("Nothing matches").assertExists()
    }

    @Test
    fun statsShowOneClockAndItsOpeningsOpenTheirCourseOrTheirGames() {
        val italian = com.chesstutor.app.domain.learn.Course(
            id = "openings-italian", category = com.chesstutor.app.domain.learn.LessonCategory.OPENINGS, title = "Italian Game",
            intro = "", level = com.chesstutor.app.domain.learn.LessonLevel.BEGINNER, order = 20, lessons = emptyList(),
        )
        var course: String? = null
        var shown: GameFilter? = null
        compose.setContent {
            CtTheme(reduceMotion = true) {
                StatsScreen(
                    games = games, state = AppUiState(), initialClock = com.chesstutor.app.domain.account.TimeClass.RAPID, now = 1_760_000_000_000,
                    courseIdFor = { family -> if (family == "Italian Game") italian.id else null },
                    onOpenCourse = { course = it }, onShowGames = { shown = it }, onBack = {},
                )
            }
        }
        compose.onNodeWithText("Score").assertExists()
        compose.onNodeWithText("Win streak").assertExists()
        compose.onNodeWithText("Won by").assertExists()
        compose.onNodeWithText("As White").performScrollTo()
        compose.onRoot().captureRoboImage("build/outputs/roborazzi/account_stats.png")
        compose.onNodeWithText("Italian Game").performScrollTo().performClick()
        assertEquals("openings-italian", course)

        compose.onAllNodes(androidx.compose.ui.test.hasContentDescription("Bullet") and hasClickAction()).onFirst().performClick()
        compose.onNodeWithText("Sicilian Defense").performScrollTo().performClick()
        assertEquals(GameFilter(timeClass = com.chesstutor.app.domain.account.TimeClass.BULLET, color = com.chesstutor.app.core.PieceColor.WHITE, openingFamily = "Sicilian Defense"), shown)
    }

    @Test
    fun trainingShowsThemesToWorkOnAndDueMistakes() {
        val history = (1..6).map { i ->
            com.chesstutor.app.domain.puzzle.PuzzleHistoryEntry("p$i", solved = true, clean = i % 2 == 0, ratingAfter = 1000 + i * 15, finishedAt = i.toLong())
        }
        val training = com.chesstutor.app.domain.account.TrainingCalculator.report(
            history,
            { id -> if (id.removePrefix("p").toInt() % 2 == 0) setOf("fork") else setOf("pin") },
            lessonsDone = 12,
            lessonsTotal = 48,
        )
        var reviewed = false
        var practised: String? = null
        compose.setContent {
            CtTheme(reduceMotion = true) {
                TrainingScreen(
                    training = training, stats = stats, dueReviewCount = 2, now = 10,
                    onReviewMistakes = { reviewed = true }, onPracticeTheme = { practised = it }, onBack = {},
                )
            }
        }
        compose.onNodeWithText("Clean").assertExists()
        compose.onNodeWithText("Themes to work on").performScrollTo()
        compose.onRoot().captureRoboImage("build/outputs/roborazzi/account_training.png")
        compose.onNodeWithText("0%").performScrollTo().performClick()
        assertEquals("pin", practised)
        compose.onNodeWithText("Mistakes to review").performScrollTo().performClick()
        assertTrue(reviewed)
    }

    @Test
    fun statsGraphTheRatingsAndAResultOpensItsGames() {
        val day = 86_400_000L
        val now = 1_760_000_000_000
        fun rated(id: String, days: Long, rating: Int, result: String) =
            record(id, "rookie99", result, "white", GameSource.CHESS_COM, "e2e4 c7c5", date = now - days * day, timeClass = "blitz")
                .copy(pgn = "[WhiteElo \"$rating\"]")
        val played = GamesState(
            loading = false,
            games = GameLibrary.summarise(listOf(rated("a", 60, 1400, "1-0"), rated("b", 20, 1430, "1/2-1/2"), rated("c", 1, 1466, "0-1")), tree),
        )
        val history = (1..4).map { i ->
            com.chesstutor.app.domain.puzzle.PuzzleHistoryEntry("p$i", solved = true, clean = true, ratingAfter = 1000 + i * 15, finishedAt = now - (5 - i) * day)
        }
        val training = com.chesstutor.app.domain.account.TrainingCalculator.report(history, { emptySet() }, 0, 0)
        var shown: GameFilter? = null
        var page by mutableStateOf("stats")
        compose.setContent {
            CtTheme(reduceMotion = true) {
                if (page == "stats") {
                    StatsScreen(games = played, state = AppUiState(), initialClock = com.chesstutor.app.domain.account.TimeClass.BLITZ, now = now, courseIdFor = { null }, onOpenCourse = {}, onShowGames = { shown = it }, onBack = {})
                } else {
                    TrainingScreen(training = training, stats = stats, dueReviewCount = 0, now = now, onReviewMistakes = {}, onPracticeTheme = {}, onBack = {})
                }
            }
        }
        compose.onNodeWithContentDescription("Rating graph, now 1466. Hold to read a day.").assertExists()
        compose.onRoot().captureRoboImage("build/outputs/roborazzi/account_stats_graph.png")
        compose.onNode(androidx.compose.ui.test.hasContentDescription("Drawn") and hasClickAction()).performClick()
        assertEquals(GameFilter(timeClass = com.chesstutor.app.domain.account.TimeClass.BLITZ, outcome = com.chesstutor.app.domain.account.GameOutcome.DRAW), shown)

        page = "training"
        compose.onNodeWithContentDescription("Rating graph, now 1060. Hold to read a day.").assertExists()
    }

    @Test
    fun theHeroShowsTheEarnedPieceAndItsLadder() {
        val state = AppUiState(
            linkedProfile = LinkedChessProfile(RatingPlatform.LICHESS, "kenny", rapidRating = 1526, blitzRating = null, bulletRating = null, selectedTimeControl = RatingTimeControl.RAPID),
        )
        compose.setContent {
            CtTheme(reduceMotion = true) {
                AccountScreen(state = state, games = games, stats = stats, actions = AccountActions())
            }
        }
        compose.onNodeWithText("274 to Queen").assertDoesNotExist()
        compose.onNodeWithContentDescription("Your piece: Rook").performClick()
        compose.onNodeWithText("Your piece").assertExists()
        compose.onNodeWithText("King").assertExists()
        compose.onNodeWithText("2200").assertExists()
    }

    @Test
    fun eachRatingOpensItsOwnPage() {
        val state = AppUiState(
            linkedProfile = LinkedChessProfile(RatingPlatform.LICHESS, "kenny", rapidRating = 1700, blitzRating = 1100, bulletRating = 1999, selectedTimeControl = RatingTimeControl.RAPID),
        )
        var clock: com.chesstutor.app.domain.account.TimeClass? = null
        var training = false
        var all: GameFilter? = null
        compose.setContent {
            CtTheme(reduceMotion = true) {
                AccountScreen(state = state, games = games, stats = stats, actions = AccountActions(onOpenStats = { clock = it }, onOpenTraining = { training = true }, onOpenGames = { all = it }))
            }
        }
        compose.onNodeWithText("Overview").assertDoesNotExist()
        compose.onNodeWithText("1100").performClick()
        assertEquals(com.chesstutor.app.domain.account.TimeClass.BLITZ, clock)
        compose.onNodeWithText("1999").performClick()
        assertEquals(com.chesstutor.app.domain.account.TimeClass.BULLET, clock)
        compose.onNodeWithText("Puzzles").performClick()
        assertTrue(training)
        compose.onNodeWithText("See all").performScrollTo().performClick()
        assertEquals(GameFilter(), all)
        compose.onNodeWithContentDescription("Your piece: Rook").assertExists()
    }

    @Test
    fun settingsPageHoldsCoachBoardAccountEngineDataAndAbout() {
        var boardOpened = false
        var chat: com.chesstutor.app.domain.bot.ChatLevel? = null
        var depth: com.chesstutor.app.data.settings.ReviewDepth? = null
        var online: Boolean? = null
        var licences = false
        var crashCleared = false
        var erased = false
        compose.setContent {
            CtTheme(reduceMotion = true) {
                SettingsScreen(
                    state = AppUiState(),
                    accountActions = AccountActions(),
                    actions = SettingsActions(
                        onOpenBoardSettings = { boardOpened = true },
                        onChatLevel = { chat = it },
                        onReviewDepth = { depth = it },
                        onOnlineEngine = { online = it },
                        onOpenLicences = { licences = true },
                        crashLog = { if (crashCleared) "" else "=== Crash 2026-10-26 10:00:00 UTC ===\nboom\n" },
                        clearCrashLog = { crashCleared = true },
                        eraseEverything = { erased = true },
                        supportUrl = "",
                    ),
                )
            }
        }
        compose.onRoot().captureRoboImage("build/outputs/roborazzi/account_settings.png")
        compose.onNodeWithText("Export my games").assertDoesNotExist()
        section("Linked account")
        compose.onNodeWithText("No account linked. Link Chess.com or Lichess on the Account page", substring = true).assertExists()
        back()
        section("Appearance")
        compose.onNodeWithText("Board and pieces").performScrollTo().performClick()
        assertTrue(boardOpened)
        back()
        section("Sound and play")
        compose.onNodeWithText("Lots").performScrollTo().performClick()
        assertEquals(com.chesstutor.app.domain.bot.ChatLevel.LOTS, chat)
        back()
        section("Engine")
        compose.onNodeWithText("Deep").performScrollTo().performClick()
        assertEquals(com.chesstutor.app.data.settings.ReviewDepth.DEEP, depth)
        compose.onNodeWithText("Online engine as a backup").performScrollTo().performClick()
        assertEquals(false, online)
        back()
        section("About")
        compose.onNodeWithText("Support the developer").assertDoesNotExist()
        compose.onNodeWithText("Open-source licences").performScrollTo().performClick()
        assertTrue(licences)
        back()
        section("Your data")
        compose.onNodeWithText("Export my games").performScrollTo().assertExists()
        compose.onNodeWithText("The app crashed 1 time recently.", substring = true).performScrollTo().assertExists()
        compose.onNodeWithText("Reports of another move that works appear here.").assertExists()
        compose.onNodeWithText("Clear").performScrollTo().performClick()
        compose.waitForIdle()
        assertTrue(crashCleared)
        compose.onNodeWithText("No crashes recorded on this phone.").assertExists()
        compose.onNodeWithText("Erase everything").performScrollTo().performClick()
        compose.onNodeWithText("Erase everything?").assertExists()
        compose.onNodeWithText("Erase").performClick()
        compose.waitForIdle()
        assertTrue(erased)
    }

    private fun section(title: String) = compose.onNodeWithText(title).performScrollTo().performClick()

    private fun back() = compose.onNodeWithContentDescription("Back").performClick()

    @Test
    fun settingsPicksTheCoachInASheetAndFlipsTheEverydaySwitches() {
        var mascot: com.chesstutor.app.domain.Mascot? = null
        var sound: Boolean? = null
        var reduceMotion: Boolean? = null
        compose.setContent {
            CtTheme(reduceMotion = true) {
                SettingsScreen(
                    state = AppUiState(),
                    accountActions = AccountActions(),
                    actions = SettingsActions(onMascot = { mascot = it }, onSound = { sound = it }, onReduceMotion = { reduceMotion = it }, supportUrl = ""),
                )
            }
        }
        section("Sound and play")
        compose.onNodeWithText("Sound").performScrollTo().performClick()
        assertEquals("sound starts on, so a tap turns it off", false, sound)
        compose.onNodeWithText("Reduce motion").performScrollTo().performClick()
        assertEquals(true, reduceMotion)
        back()
        section("Profile")
        compose.onNodeWithText("Coach").performScrollTo().performClick()
        compose.onNode(hasText("Sage") and hasClickAction()).performClick()
        compose.waitForIdle()
        assertEquals(com.chesstutor.app.domain.Mascot.SAGE, mascot)
        compose.onNodeWithText("Your coach").assertDoesNotExist()
    }

    @Test
    fun theLicencesPageCreditsEveryPartAndOpensLicenceTexts() {
        compose.setContent { CtTheme(reduceMotion = true) { LicencesScreen(onBack = {}) } }
        compose.onNodeWithText("Stockfish 19 chess engine").assertExists()
        compose.onNodeWithText("Kenney (kenney.nl)", substring = true).performScrollTo().assertExists()
        compose.onNode(hasText("GNU General Public License v3.0") and hasClickAction()).performScrollTo().performClick()
        // The text is read from the app's assets off the main thread.
        compose.waitUntil(5_000) { compose.onAllNodesWithText("TERMS AND CONDITIONS", substring = true).fetchSemanticsNodes().isNotEmpty() }
    }

    @Test
    fun aLinkedAccountIsManagedInSettingsNotOnTheAccountPage() {
        val state = AppUiState(
            linkedProfile = LinkedChessProfile(RatingPlatform.LICHESS, "kenny", rapidRating = 1848, blitzRating = 1720, bulletRating = null, selectedTimeControl = RatingTimeControl.RAPID),
        )
        var page by mutableStateOf("account")
        var imported = false
        compose.setContent {
            CtTheme(reduceMotion = true) {
                val actions = AccountActions(onImportMore = { imported = true })
                if (page == "account") {
                    AccountScreen(state = state, games = games, stats = stats, actions = actions)
                } else {
                    SettingsScreen(state = state, accountActions = actions, actions = SettingsActions(supportUrl = "https://example.org/support"))
                }
            }
        }
        compose.onNodeWithText("@kenny").assertExists()
        compose.onNodeWithText("Lichess").assertExists()
        compose.onNodeWithText("1848").assertExists()
        compose.onNodeWithText("Link your account").assertDoesNotExist()
        compose.onNodeWithContentDescription("Settings").assertExists()

        page = "settings"
        section("Linked account")
        compose.onNodeWithText("@kenny on Lichess").assertExists()
        compose.onNodeWithText("Rapid 1848 · Blitz 1720 · Bullet –").assertExists()
        compose.onNodeWithText("Blitz").assertDoesNotExist()
        compose.onNodeWithText("Import 100 more").performClick()
        assertTrue(imported)
        back()
        section("About")
        compose.onNodeWithText("Support the developer").assertExists()
    }

    @Test
    fun gamePageShowsOpeningBoardAndActions() {
        val game = games.game("bot_1")!!
        var reviewed = false
        var deleted = false
        var course: String? = null
        compose.setContent {
            CtTheme(reduceMotion = true) {
                GameDetailScreen(
                    game = game,
                    settings = AppSettings(),
                    actions = GameDetailActions(onReview = { reviewed = true }, onDelete = { deleted = true }, onOpenCourse = { course = it }),
                    courseId = "openings-italian",
                    now = game.dateMillis,
                )
            }
        }
        compose.onNodeWithText("You won").assertExists()
        compose.onNodeWithText("Checkmate, 3 moves, today").assertExists()
        compose.onNodeWithText("Italian Game").assertExists()
        compose.onNodeWithText("Giuoco Piano").assertExists()
        compose.onNodeWithText("Accuracy", substring = true).assertDoesNotExist()
        compose.onRoot().captureRoboImage("build/outputs/roborazzi/account_game.png")

        // The board opens on the final position; stepping back moves the strip with it.
        compose.onNodeWithContentDescription("Next move").assertIsNotEnabled()
        compose.onNodeWithContentDescription("Previous move").performClick()
        compose.onNodeWithContentDescription("Next move").assertIsEnabled()
        compose.onNodeWithText("Nf3").performClick()
        compose.onNodeWithText("Italian Game").performClick()
        assertEquals("openings-italian", course)
        compose.onNodeWithText("Review").performClick()
        assertTrue(reviewed)
        compose.onNodeWithContentDescription("More options").performClick()
        compose.onNodeWithText("Delete game").performClick()
        compose.onNodeWithText("Delete this game?").assertExists()
        compose.onNodeWithText("Delete").performClick()
        assertTrue(deleted)
    }

    @Test
    fun aDeletedGameShowsAPlainPage() {
        compose.setContent { CtTheme(reduceMotion = true) { GameDetailScreen(game = null, settings = AppSettings(), actions = GameDetailActions()) } }
        compose.onNodeWithText("This game is no longer saved").assertExists()
    }

    @Test
    fun bookLineSaysWhoLeftTheBook() {
        val strange = GameLibrary.summarise(
            record("x", "Pip", "0-1", "black", GameSource.ARENA, "e2e4 e7e5 g1f3 b8c6 f1c4 f8c5 e1f1 g8f6", date = 1),
            tree,
        )
        assertTrue(openingDetail(strange)!!.endsWith("out of book on move 4"))
        assertEquals("You lost", resultTitle(strange.copy(outcome = com.chesstutor.app.domain.account.GameOutcome.LOSS)))
    }
}
